import csv
def getDataInput():
  data = []
  with open('RealEstateData.csv', newline='') as csvfile:
      reader = csv.reader(csvfile)
      next(reader)
      for row in reader:
          data.append(row)
  return data
def getMedian(data):
  sorted_data = sorted(data)
  n = len(sorted_data)
  if n % 2 == 0:
    return (sorted_data[n//2 - 1] + sorted_data[n//2]) / 2
  else:
    return sorted_data[n//2]
def main():
  records = getDataInput()
  lPropertyPrices = []
  dictCityTotal = {}
  dictPropertyTypeTotal = {}
  for record in records:
    city = record[1]
    sPropertyType = record[7]
    fPrice = float(record[8])
    lPropertyPrices.append(fPrice)
    dictCityTotal[city] = dictCityTotal.get(city, 0) + fPrice
    dictPropertyTypeTotal[sPropertyType] = dictPropertyTypeTotal.get(sPropertyType, 0) + fPrice
  lPropertyPrices.sort()
  fMinPrice = (lPropertyPrices[0])
  fMaxPrice = (lPropertyPrices[-1])
  fTotalPrice = (sum(lPropertyPrices))
  fAveragePrice = (sum(lPropertyPrices) / len(lPropertyPrices))
  fMedianPrice = getMedian(lPropertyPrices)
  print("Overall summary: ")
  print(f"Minimum Price: {fMinPrice:,.2f}")
  print(f"Maximum Price: {fMaxPrice:,.2f}")
  print(f"Total Price: {fTotalPrice:,.2f}")
  print(f"Average Price: {fAveragePrice:,.2f}")
  print(f"Median Price: {fMedianPrice:,.2f}")
  print("\nSummaries by City:")
  for city, fTotal in dictCityTotal.items():
    print(f"{city}: {fTotal:,.2f}")
  print("\nSummaries by Property Type:")
  for sPropertyType, total in dictPropertyTypeTotal.items():
    print(f"{sPropertyType}: {total:,.2f}")
main()